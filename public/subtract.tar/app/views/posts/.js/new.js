(function() {
  var PostsNewView;
  var __hasProp = Object.prototype.hasOwnProperty, __extends = function(child, parent) {
    for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; }
    function ctor() { this.constructor = child; }
    ctor.prototype = parent.prototype;
    child.prototype = new ctor;
    child.__super__ = parent.prototype;
    return child;
  }, __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  PostsNewView = (function() {
    function PostsNewView() {
      PostsNewView.__super__.constructor.apply(this, arguments);
    }
    __extends(PostsNewView, Backbone.View);
    PostsNewView.prototype.initialize = function() {
      this.template = $templates.postsNew;
      return this.render();
    };
    PostsNewView.prototype.events = {};
    PostsNewView.prototype.render = function() {
      $(this.el).html(this.template(this));
      this.delegateEvents();
      return this.addAutocomplete();
    };
    PostsNewView.prototype.addAutocomplete = function() {
      var autocomplete, input;
      input = $(this.el).find('input');
      autocomplete = new google.maps.places.Autocomplete(input[0]);
      return google.maps.event.addListener(autocomplete, 'place_changed', __bind(function() {
        var place;
        place = autocomplete.getPlace();
        console.log(place);
        this.$("address").text(place.formatted_address);
        setTimeout(__bind(function() {
          return input.val(place.name);
        }, this), 250);
        return this.$(".f-content").removeClass('disabled').find('textarea').focus();
      }, this));
    };
    return PostsNewView;
  })();
  this.PostsNewView = PostsNewView;
}).call(this);
